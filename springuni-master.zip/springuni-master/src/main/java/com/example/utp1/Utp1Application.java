package com.example.utp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Utp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Utp1Application.class, args);
	}

}
